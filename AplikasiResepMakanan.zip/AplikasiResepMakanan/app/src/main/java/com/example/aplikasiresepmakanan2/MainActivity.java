package com.example.aplikasiresepmakanan2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.aplikasiresepmakanan2.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Button btnBaksoHalus, btnBaksoUrat;
    private DrawerLayout drawerLayout;
    private ImageView ivMenu;
    private RecyclerView rvMenu;
    static ArrayList<String> arrayList = new ArrayList<>();
    static ArrayList<Integer> image = new ArrayList<>();
    private MainDrawerAdapter adapter;


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finishAndRemoveTask();

        this.finishAffinity();
    }








    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        drawerLayout = findViewById(R.id.drawer_layout);
        ivMenu = findViewById(R.id.ivMenu);
        rvMenu = findViewById(R.id.rvMenu);

        arrayList.clear();

        arrayList.add("BERANDA");
        arrayList.add("KELUAR");

        image.add(R.drawable.ic_baseline_home_24);
        image.add(R.drawable.ic_baseline_logout_24);

        adapter = new MainDrawerAdapter(this, arrayList, image);

        rvMenu.setLayoutManager(new LinearLayoutManager(this));
        rvMenu.setAdapter(adapter);

        ivMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });


        btnBaksoHalus = (Button) findViewById(R.id.btnBaksoHalus);
        btnBaksoUrat = (Button) findViewById(R.id.btnBaksoUrat);

        btnBaksoHalus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Selengkapnya1 = new Intent(getApplicationContext(), BaksoHalus.class);
                startActivity(Selengkapnya1);
            }
        });

        btnBaksoUrat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bakso2();
            }
        });



    }
    public void bakso2 (){
        Intent Selengkapnya2 = new Intent(getApplicationContext(), BaksoUrat.class);
        startActivity(Selengkapnya2);
    }

    @Override
    protected void onPause() {

        super.onPause();
        closeDrawer(drawerLayout);
    }

    public static void closeDrawer(DrawerLayout drawerLayout) {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }

}